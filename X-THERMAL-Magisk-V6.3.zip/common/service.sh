#!/system/bin/sh
MODDIR=${0%/*}

sleep 45
$MODDIR/shellscript 2>/dev/null